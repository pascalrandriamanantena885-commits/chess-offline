package com.ice.app

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.net.URI
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class Found(val url: String, val title: String, val ua: String, val referer: String, val cookie: String?)

class Task(val name: String) {
    @Volatile var progress = 0
    @Volatile var state = "Eo am-pakàna"
    @Volatile var done = false
}

object Downloader {
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()
    private val pool = Executors.newFixedThreadPool(2)
    val tasks = CopyOnWriteArrayList<Task>()

    // filesDir = fitahirizana anatiny an'ny app: tsy hita ao amin'ny Galerie na fichier amin'ny phone
    fun dir(c: Context): File = File(c.filesDir, "videos").apply { mkdirs() }

    private fun req(f: Found, url: String): Request {
        val b = Request.Builder().url(url).header("User-Agent", f.ua)
        if (f.referer.isNotEmpty()) b.header("Referer", f.referer)
        f.cookie?.let { b.header("Cookie", it) }
        return b.build()
    }

    fun start(c: Context, f: Found) {
        val app = c.applicationContext
        val isHls = f.url.substringBefore('?').endsWith(".m3u8")
        val base = f.title.replace(Regex("[^\\p{L}\\p{N} _-]"), "").trim().take(40).ifEmpty { "video" }
        val ext = if (isHls) ".ts" else ".mp4"
        val file = File(dir(app), base + "_" + (System.currentTimeMillis() % 100000) + ext)
        val t = Task(file.name)
        tasks.add(t)
        pool.execute {
            try {
                if (isHls) hls(f, file, t) else direct(f, file, t)
                t.progress = 100
                t.state = "Vita"
            } catch (e: Exception) {
                file.delete()
                t.state = "Tsy nahomby: " + (e.message ?: "")
            }
            t.done = true
        }
    }

    private fun direct(f: Found, out: File, t: Task) {
        http.newCall(req(f, f.url)).execute().use { r ->
            if (!r.isSuccessful) throw Exception("HTTP " + r.code)
            val body = r.body ?: throw Exception("foana")
            val total = body.contentLength()
            out.outputStream().use { o ->
                body.byteStream().use { i ->
                    val buf = ByteArray(65536)
                    var n: Int
                    var sum = 0L
                    while (i.read(buf).also { n = it } >= 0) {
                        o.write(buf, 0, n)
                        sum += n
                        if (total > 0) t.progress = (sum * 100 / total).toInt()
                    }
                }
            }
        }
    }

    private fun text(f: Found, url: String): String {
        http.newCall(req(f, url)).execute().use { r ->
            if (!r.isSuccessful) throw Exception("HTTP " + r.code)
            return r.body!!.string()
        }
    }

    private fun hls(f: Found, out: File, t: Task) {
        var url = f.url
        var pl = text(f, url)
        if (pl.contains("#EXT-X-STREAM-INF")) {
            val lines = pl.lines()
            var best = -1L
            var uri = ""
            for (i in lines.indices) {
                if (lines[i].startsWith("#EXT-X-STREAM-INF")) {
                    val bw = Regex("BANDWIDTH=(\\d+)").find(lines[i])?.groupValues?.get(1)?.toLong() ?: 0L
                    val next = lines.drop(i + 1).firstOrNull { it.isNotBlank() && !it.startsWith("#") }
                    if (next != null && bw > best) { best = bw; uri = next }
                }
            }
            url = URI(url).resolve(uri.trim()).toString()
            pl = text(f, url)
        }
        if (pl.contains("#EXT-X-KEY") && !pl.contains("METHOD=NONE")) throw Exception("video voaaro")
        val segs = pl.lines().filter { it.isNotBlank() && !it.startsWith("#") }
            .map { URI(url).resolve(it.trim()).toString() }
        if (segs.isEmpty()) throw Exception("tsy nahitana ampahany")
        out.outputStream().use { o ->
            segs.forEachIndexed { i, s ->
                http.newCall(req(f, s)).execute().use { r ->
                    if (!r.isSuccessful) throw Exception("HTTP " + r.code)
                    r.body!!.byteStream().copyTo(o)
                }
                t.progress = (i + 1) * 100 / segs.size
            }
        }
    }
}
