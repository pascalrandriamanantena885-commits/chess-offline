package com.ice.app

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONTokener

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var urlBox: EditText
    private lateinit var foundBtn: Button
    private lateinit var bar: ProgressBar
    private val found = ArrayList<Found>()
    private val ui = Handler(Looper.getMainLooper())
    private val videoRx = Regex("\\.(mp4|m4v|webm|mov|m3u8)(\\?|$)", RegexOption.IGNORE_CASE)

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    // Mitady <video> ao anaty pejy isaky ny 3 segondra
    private val poll = object : Runnable {
        override fun run() {
            val js = "(function(){var r=[];document.querySelectorAll('video').forEach(function(v){" +
                "var s=v.currentSrc||v.src;if(s&&s.indexOf('http')==0)r.push(s)});return JSON.stringify(r)})()"
            web.evaluateJavascript(js) { res ->
                try {
                    val arr = JSONArray(JSONTokener(res).nextValue() as String)
                    for (i in 0 until arr.length()) add(arr.getString(i))
                } catch (_: Exception) {}
            }
            ui.postDelayed(this, 3000)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; fitsSystemWindows = true }

        urlBox = EditText(this).apply {
            hint = "Tadiavo na apetaho ny rohy"
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_GO
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        val go = Button(this).apply { text = "Mandeha"; setOnClickListener { load() } }
        val top = LinearLayout(this).apply {
            setPadding(dp(8), dp(4), dp(8), dp(4)); gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(urlBox, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(go)

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; visibility = View.GONE
        }

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                bar.progress = newProgress
                bar.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
            }
        }
        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                found.clear(); refresh(); urlBox.setText(url)
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                !(request.url.scheme ?: "").startsWith("http")
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val u = request.url.toString()
                if (looksVideo(u)) ui.post { add(u) }
                return null
            }
        }

        val back = Button(this).apply { text = "◀"; setOnClickListener { if (web.canGoBack()) web.goBack() } }
        foundBtn = Button(this).apply { text = "⬇ Video hita (0)"; setOnClickListener { showFound() } }
        val lib = Button(this).apply {
            text = "Tahiry"
            setOnClickListener { startActivity(Intent(this@MainActivity, LibraryActivity::class.java)) }
        }
        val bottom = LinearLayout(this)
        bottom.addView(back, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        bottom.addView(foundBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 3f))
        bottom.addView(lib, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 2f))

        root.addView(top)
        root.addView(bar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(3)))
        root.addView(web, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(bottom)
        setContentView(root)

        urlBox.setOnEditorActionListener { _, _, _ -> load(); true }
        web.loadUrl("https://www.google.com")
    }

    private fun load() {
        val t = urlBox.text.toString().trim()
        if (t.isEmpty()) return
        val u = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains(".") && !t.contains(" ") -> "https://$t"
            else -> "https://www.google.com/search?q=" + Uri.encode(t)
        }
        web.loadUrl(u)
    }

    private fun looksVideo(u: String) =
        videoRx.containsMatchIn(u) || u.contains("mime_type=video") || u.contains("video/mp4")

    // Facebook: esorina ny bytestart/byteend mba ho feno ny rakitra
    private fun clean(u: String): String {
        val uri = Uri.parse(u)
        if (uri.getQueryParameter("bytestart") == null && uri.getQueryParameter("byteend") == null) return u
        val nb = uri.buildUpon().clearQuery()
        uri.queryParameterNames.filter { it != "bytestart" && it != "byteend" }
            .forEach { nb.appendQueryParameter(it, uri.getQueryParameter(it)) }
        return nb.build().toString()
    }

    private fun add(raw: String) {
        if (!looksVideo(raw) && !raw.startsWith("http")) return
        val u = clean(raw)
        if (found.any { it.url == u }) return
        found.add(Found(u, web.title ?: "video", web.settings.userAgentString,
            web.url ?: "", CookieManager.getInstance().getCookie(u)))
        refresh()
    }

    private fun refresh() { foundBtn.text = "⬇ Video hita (" + found.size + ")" }

    private fun showFound() {
        val b = AlertDialog.Builder(this)
        if (found.isEmpty()) {
            b.setMessage("Mbola tsy nahita video. Alefaso ny video ao amin'ny pejy, dia jereo indray.")
        } else {
            val labels = found.map {
                val kind = if (it.url.substringBefore('?').endsWith(".m3u8")) "HLS" else "MP4"
                kind + " · " + (Uri.parse(it.url).host ?: "") + "\n" + it.title.take(40)
            }.toTypedArray()
            b.setTitle("Safidio ny alaina")
            b.setItems(labels) { _, i ->
                Downloader.start(this, found[i])
                Toast.makeText(this, "Natomboka ny fampidinana. Jereo ao amin'ny Tahiry.", Toast.LENGTH_LONG).show()
            }
        }
        b.setNegativeButton("Akatony", null).show()
    }

    override fun onResume() { super.onResume(); ui.postDelayed(poll, 1500) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(poll) }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
