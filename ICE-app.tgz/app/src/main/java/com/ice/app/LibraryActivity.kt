package com.ice.app

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.format.Formatter
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.File

class LibraryActivity : AppCompatActivity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var adapter: ArrayAdapter<String>
    private var shownTasks = listOf<Task>()
    private var files = listOf<File>()

    private val tick = object : Runnable {
        override fun run() { refresh(); ui.postDelayed(this, 1000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; fitsSystemWindows = true }
        val head = TextView(this).apply {
            text = "Tahiry ICE (miafina ao amin'ny app ihany)"
            textSize = 18f; setPadding(32, 24, 32, 24)
        }
        val list = ListView(this)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, ArrayList<String>())
        list.adapter = adapter
        root.addView(head)
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        list.setOnItemClickListener { _, _, pos, _ ->
            if (pos < shownTasks.size) {
                val t = shownTasks[pos]
                if (t.done) { Downloader.tasks.remove(t); refresh() }
            } else {
                val f = files[pos - shownTasks.size]
                startActivity(Intent(this, PlayerActivity::class.java).putExtra("path", f.absolutePath))
            }
        }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            if (pos >= shownTasks.size) options(files[pos - shownTasks.size])
            true
        }
    }

    private fun options(f: File) {
        AlertDialog.Builder(this).setTitle(f.name)
            .setItems(arrayOf("Ovay anarana", "Fafao")) { _, i ->
                if (i == 1) {
                    AlertDialog.Builder(this).setMessage("Fafana ve ity video ity?")
                        .setPositiveButton("Eny") { _, _ -> f.delete(); refresh() }
                        .setNegativeButton("Tsia", null).show()
                } else {
                    val et = EditText(this).apply { setText(f.nameWithoutExtension) }
                    AlertDialog.Builder(this).setTitle("Anarana vaovao").setView(et)
                        .setPositiveButton("Ok") { _, _ ->
                            val n = et.text.toString().replace(Regex("[^\\p{L}\\p{N} _-]"), "").trim()
                            if (n.isNotEmpty()) f.renameTo(File(f.parentFile, n + "." + f.extension))
                            refresh()
                        }.setNegativeButton("Akatony", null).show()
                }
            }.show()
    }

    private fun refresh() {
        shownTasks = Downloader.tasks.filter { !(it.done && it.state == "Vita") }
        val active = shownTasks.map { it.name }.toSet()
        files = (Downloader.dir(this).listFiles()?.toList() ?: emptyList())
            .filter { it.name !in active }.sortedByDescending { it.lastModified() }
        val rows = ArrayList<String>()
        shownTasks.forEach {
            rows.add(if (it.done) "⚠ " + it.name + "\n" + it.state + " (tsindrio hanala)"
                     else "⬇ " + it.name + "\n" + it.progress + "%")
        }
        files.forEach { rows.add("▶ " + it.name + "\n" + Formatter.formatFileSize(this, it.length())) }
        adapter.clear(); adapter.addAll(rows); adapter.notifyDataSetChanged()
    }

    override fun onResume() { super.onResume(); ui.post(tick) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(tick) }
}
