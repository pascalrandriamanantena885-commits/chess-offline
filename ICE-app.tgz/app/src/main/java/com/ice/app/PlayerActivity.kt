package com.ice.app

import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.io.File

class PlayerActivity : AppCompatActivity() {
    private var exo: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val path = intent.getStringExtra("path") ?: return finish()
        val p = ExoPlayer.Builder(this).build()
        exo = p
        p.setMediaItem(MediaItem.fromUri(Uri.fromFile(File(path))))
        p.prepare()
        p.playWhenReady = true

        val view = PlayerView(this).apply {
            this.player = p
            setShowNextButton(false)
            setShowPreviousButton(false)
        }

        val speeds = floatArrayOf(0.5f, 1f, 1.5f, 2f)
        var si = 1
        fun btn(t: String, f: (Button) -> Unit) = Button(this).apply {
            text = t; setOnClickListener { f(this) }
        }
        val bar = LinearLayout(this).apply {
            setBackgroundColor(0x99000000.toInt()); gravity = Gravity.CENTER
        }
        bar.addView(btn("⏪ 10") { p.seekTo(maxOf(0, p.currentPosition - 10000)) })
        bar.addView(btn("10 ⏩") { p.seekTo(p.currentPosition + 10000) })
        bar.addView(btn("1x") { b ->
            si = (si + 1) % speeds.size
            p.setPlaybackSpeed(speeds[si])
            b.text = speeds[si].toString().removeSuffix(".0") + "x"
        })
        bar.addView(btn("Averina") { b ->
            val on = p.repeatMode == Player.REPEAT_MODE_OFF
            p.repeatMode = if (on) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
            b.text = if (on) "Averina ✓" else "Averina"
        })
        bar.addView(btn("🔇") { b ->
            val mute = p.volume > 0f
            p.volume = if (mute) 0f else 1f
            b.text = if (mute) "🔊" else "🔇"
        })
        bar.addView(btn("↻") {
            requestedOrientation =
                if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE)
                    ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        })

        view.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { v ->
            bar.visibility = v
        })

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); fitsSystemWindows = true }
        root.addView(view, FrameLayout.LayoutParams(-1, -1))
        root.addView(bar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        setContentView(root)
    }

    override fun onPause() { super.onPause(); exo?.pause() }
    override fun onDestroy() { super.onDestroy(); exo?.release(); exo = null }
}
