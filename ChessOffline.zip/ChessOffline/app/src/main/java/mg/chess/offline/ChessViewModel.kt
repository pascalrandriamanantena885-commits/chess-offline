package mg.chess.offline

import android.app.Application
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.github.bhlangonijr.chesslib.*
import com.github.bhlangonijr.chesslib.move.Move
import kotlinx.coroutines.launch

class ChessViewModel(app: Application) : AndroidViewModel(app) {
    private val engine = Engine(app)
    val board = Board()
    var version by mutableIntStateOf(0); private set   // mba hamerenana recomposition
    var inGame by mutableStateOf(false)
    var vsBot by mutableStateOf(false)
    var humanWhite by mutableStateOf(true)
    var skill by mutableIntStateOf(5)
    var selected by mutableStateOf<Square?>(null)
    var thinking by mutableStateOf(false)
    var message by mutableStateOf("")

    fun newGame(bot: Boolean, white: Boolean) {
        board.loadFromFen(Board().fen)
        vsBot = bot; humanWhite = white; selected = null; inGame = true
        refresh()
        if (bot && !white) botMove()
    }

    fun backToMenu() { inGame = false }

    private fun humanTurn() = !vsBot || (board.sideToMove == Side.WHITE) == humanWhite

    fun legalFrom(sq: Square) = board.legalMoves().filter { it.from == sq }

    fun onSquare(sq: Square) {
        if (thinking || !humanTurn() || isOver()) return
        val sel = selected
        val piece = board.getPiece(sq)
        if (sel == null || (piece != Piece.NONE && piece.pieceSide == board.sideToMove)) {
            selected = if (piece != Piece.NONE && piece.pieceSide == board.sideToMove) sq else null
            return
        }
        val mv = legalFrom(sel).filter { it.to == sq }
            .let { l -> l.firstOrNull { it.promotion.pieceType == PieceType.QUEEN } ?: l.firstOrNull() }
        selected = null
        if (mv != null) { board.doMove(mv); refresh(); if (vsBot && !isOver()) botMove() }
    }

    private fun botMove() {
        thinking = true
        viewModelScope.launch {
            val uci = engine.bestMove(board.fen, skill, 700 + skill * 60)
            val mv = board.legalMoves().firstOrNull { it.toString().equals(uci, true) }
            if (mv != null) board.doMove(mv)
            else message = "Tsy hita ny Stockfish (libstockfish.so)"
            thinking = false; refresh()
        }
    }

    fun undo() {
        if (thinking || board.backup.isEmpty()) return
        board.undoMove()
        if (vsBot && !humanTurn() && board.backup.isNotEmpty()) board.undoMove()
        selected = null; refresh()
    }

    fun isOver() = board.isMated || board.isDraw || board.legalMoves().isEmpty()

    private fun refresh() {
        message = when {
            board.isMated -> "Checkmate! " + (if (board.sideToMove == Side.WHITE) "Mainty" else "Fotsy") + " no nahazo"
            board.isDraw || board.legalMoves().isEmpty() -> "Draw"
            board.isKingAttacked -> "Check!"
            else -> ""
        }
        version++
    }

    override fun onCleared() { engine.stop() }
}
