package mg.chess.offline

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.github.bhlangonijr.chesslib.*

class MainActivity : ComponentActivity() {
    private val vm: ChessViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { if (vm.inGame) GameScreen(vm) else MenuScreen(vm) } } }
    }
}

@Composable
fun MenuScreen(vm: ChessViewModel) {
    var white by remember { mutableStateOf(true) }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("♞ Chess Offline", fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(32.dp))
        Button({ vm.newGame(false, true) }, Modifier.fillMaxWidth()) { Text("Olona vs Olona") }
        Spacer(Modifier.height(16.dp))
        Button({ vm.newGame(true, white) }, Modifier.fillMaxWidth()) { Text("Olona vs Stockfish") }
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Ny loko: "); FilterChip(white, { white = true }, { Text("Fotsy") })
            Spacer(Modifier.width(8.dp)); FilterChip(!white, { white = false }, { Text("Mainty") })
        }
        Text("Haavon'ny bot: ${vm.skill} / 20")
        Slider(vm.skill.toFloat(), { vm.skill = it.toInt() }, valueRange = 0f..20f)
    }
}

private fun glyph(p: Piece): String {
    val w = p.pieceSide == Side.WHITE
    return when (p.pieceType) {
        PieceType.KING -> if (w) "♔" else "♚"
        PieceType.QUEEN -> if (w) "♕" else "♛"
        PieceType.ROOK -> if (w) "♖" else "♜"
        PieceType.BISHOP -> if (w) "♗" else "♝"
        PieceType.KNIGHT -> if (w) "♘" else "♞"
        else -> if (w) "♙" else "♟"
    }
}

@Composable
fun GameScreen(vm: ChessViewModel) {
    BackHandler { vm.backToMenu() }
    vm.version // mamaky state mba hirecompose
    val flip = vm.vsBot && !vm.humanWhite
    val targets = vm.selected?.let { s -> vm.legalFrom(s).map { it.to } } ?: emptyList()
    Column(Modifier.fillMaxSize().padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            when { vm.thinking -> "Stockfish mieritreritra..."; else -> if (vm.board.sideToMove == Side.WHITE) "Fotsy no mihetsika" else "Mainty no mihetsika" },
            Modifier.padding(8.dp), fontSize = 18.sp
        )
        Text(vm.message, color = Color(0xFFB00020), fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Spacer(Modifier.height(8.dp))
        BoxWithConstraints(Modifier.fillMaxWidth().aspectRatio(1f)) {
            val cell = maxWidth / 8
            Column {
                for (r in 0..7) Row {
                    for (f in 0..7) {
                        val rank = if (flip) r else 7 - r
                        val file = if (flip) 7 - f else f
                        val sq = Square.encode(Rank.allRanks[rank], File.allFiles[file])
                        val dark = (rank + file) % 2 == 0
                        val bg = when {
                            sq == vm.selected -> Color(0xFFF6F669)
                            dark -> Color(0xFF769656) else -> Color(0xFFEEEED2)
                        }
                        Box(Modifier.size(cell).background(bg).clickable { vm.onSquare(sq) }, contentAlignment = Alignment.Center) {
                            val p = vm.board.getPiece(sq)
                            if (p != Piece.NONE) Text(glyph(p), fontSize = (cell.value * 0.75f).sp, color = Color.Black)
                            if (sq in targets) Box(Modifier.size(cell / 3).background(Color(0x88000000), androidx.compose.foundation.shape.CircleShape))
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button({ vm.undo() }) { Text("Undo") }
            Button({ vm.newGame(vm.vsBot, vm.humanWhite) }) { Text("Vaovao") }
            OutlinedButton({ vm.backToMenu() }) { Text("Menu") }
        }
    }
}
